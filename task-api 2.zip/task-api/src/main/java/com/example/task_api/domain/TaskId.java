package com.example.task_api.domain;

@Embeddable
public record TaskId @Column(name = "id")
                    UUID value)  {

    public TaskId {
        Objects.requireNonNull(value, "O id da task não pode se nulo");
    }

    public static TaskId newId() {
        return new TaskId(UUID.randonUUID());
    }
}